#include "syscall.h"

int main() {
	PutChar('a') ;
	PutChar('\n');
	Halt();
}
