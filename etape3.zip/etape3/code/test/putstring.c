#include "syscall.h"


int main()
{
    //PutString("Allo la lune ici Houston !\n");
    PutString("SOS1\n");
    PutString("SOS2\n");
    PutString("SOS3\n");
    PutString("SOS4\n");
    PutString("SOS5\n");
    PutString("SOS6\n");
    Halt();
}

